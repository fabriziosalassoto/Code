#include "fwkw.h"
#include "winmain.h"

IControl* MakeMyCtrl(IControl* hParent,CTRLLOC* pLocn);

class invoicestarter : public IMObject
{
public:
	invoicestarter(void);
	~invoicestarter(void);
	virtual void* Msg(MSGDISPATCH);	
	
public:
	IWindow*        hWindow;	
	IControl*		hInnerControl;						
};

IApplication* MakeApplication(void)
{
	return (IApplication*) new invoicestarter();
}

invoicestarter::invoicestarter(void){
	pApplication = this;	
	hWindow = NULL;

	LoadDefaultResources();

	SESSION* ssnptr = hSession->SsnGetDataPtr();
	ssnptr->fUntitledWin = false;

	hWindow = MakeWindow(WINTYPE_DOCWIN,NULL,0,0,1024,700,true,false);
	hWindow->WinQuitOnClose();	
	hWindow->WinSetTitle(TEXT("LIST OF INVOICES - POS"));	

	CTRLLOC CtlLocn = {ALL,{0,0,0,0},0};
	hInnerControl = MakeMyCtrl(hWindow,&CtlLocn);	
	
	hWindow->WinCtrlsChanged();
	hWinMgr->WMgrSetFocus(hInnerControl);			
}




invoicestarter::~invoicestarter(void){
}

static WCHAR szAppVersion[] = VER_DISPLAY_CT;
static char szAppDate[] = __DATE__;
static WCHAR* szAppName = TEXT("invoicestarter\0");

void* invoicestarter::Msg(MSGDISPATCH)
{
	switch(MSGID){
	    case MSG_AppVersionText:	return MRTNVAL(szAppVersion);
		case MSG_AppVersionDate:	return MRTNVAL(szAppDate);
		case MSG_AppName:			return MRTNVAL(szAppName);
		case MSG_CtlWindow:			return MRTNVAL(hWindow);
		case MSG_WinClose :			((IWindow*)hInnerControl)->WinClose();
			return IM_RTN_NOTHING;
	}	
	return IM_RTN_NOTHING;
}