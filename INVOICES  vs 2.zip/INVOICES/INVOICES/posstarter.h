#pragma once
class posstarter
{
public:
	posstarter(void);
	~posstarter(void);
};

