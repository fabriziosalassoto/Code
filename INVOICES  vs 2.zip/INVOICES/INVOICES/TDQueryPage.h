#pragma once
class CTDQueryPage
{
public:
	CTDQueryPage(void);
	~CTDQueryPage(void);
};

