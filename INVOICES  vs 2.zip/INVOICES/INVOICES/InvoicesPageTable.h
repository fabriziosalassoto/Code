#pragma once
class CInvoicesPageTable
{
public:
	CInvoicesPageTable(void);
	~CInvoicesPageTable(void);
};

