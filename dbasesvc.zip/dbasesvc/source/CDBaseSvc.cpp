//	==============================================================================
//	CDBaseSvc.cpp - XP main singleton object: MySQL database services plugin
//	------------------------------------------------------------------------------
//	Copyright � 2011 Evolution Computing, Inc.
//	All rights reserved
//	==============================================================================

#include "fwkw.h"
#include "CDBaseSvc.h"

//	these are necessary to allow both static and DLL versions of this code to be used
IMObject* MakeDBaseSvc(HANDLE hModule){return new CDBaseSvc(hModule);}
#define MakeXPMain MakeDBaseSvc

//	this includes the DLL module prefix code
#include "xpmain.h"

IMObject*	hDBaseSvc = NULL;
UINT		nDBaseSvcSlot = 0;
UINT		nDBaseSvcRscBase = 0;
HANDLE		hDBaseSvcDLL = 0;

IMObject* MakeDBSvc(void);

//	==============================================================================
//	Initialize when used as a static library
//	==============================================================================

DLLEXPORT void InitDBaseSvc(void)
{
	pgp = GetGPAdr(); 
	MakeDBaseSvc(0);
}

//	==============================================================================
//	Constructor
//	==============================================================================

CDBaseSvc::CDBaseSvc(HANDLE hModule) : CDbObject(hXPList,XPID)
{
	hDBaseSvcDLL = hModule;
	nDBaseSvcSlot = hXPMgr->GetSlotNr(XPID);
	nDBaseSvcRscBase = nDBaseSvcSlot<<16;	// base for resource ids
	hDBaseSvc = this;

	pDBSvc = (IMObject*)MakeDBSvc();
}

//	==============================================================================
//	Destructor
//	==============================================================================

CDBaseSvc::~CDBaseSvc(void)
{
}

//	==============================================================================
//	Variable length message receiver/dispatcher
//	==============================================================================

void* CDBaseSvc::Msg(MSGDISPATCH)
{
	

	//	process CDbObject messages
	if((MSGID & MSGC_MASK) == MSGC_DBOBJ)
		return MSGFWDBASE(CDbObject,MSGID);

	switch(MSGID)
	{
		case MSG_DbOType:return (void*)((UINT)FWK_XP);
//		case MSG_SysEndAppNotify: hDBMgr->Release(); return IM_RTN_NOTHING;
	}

	return IM_RTN_IGNORED;
}

//	==============================================================================
