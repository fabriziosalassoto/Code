//	==============================================================================
//	CDBaseSvc.h - XP main singleton object: MySQL database services plugin
//	------------------------------------------------------------------------------
//	Copyright � 2011 Evolution Computing, Inc.
//	All rights reserved
//	==============================================================================
#ifndef _CDBASESVC_H
#define _CDBASESVC_H

#define XPID 0x1007
extern UINT nDBaseSvcSlot;
extern UINT nDBaseSvcRscBase;
extern IMObject* hDBaseSvc;

class CDBaseSvc : public CDbObject
{
public:
	CDBaseSvc(HANDLE hModule);
	~CDBaseSvc(void);
	virtual void* Msg(MSGDISPATCH);
public:
};

//	==============================================================================
//	Resource identifiers
//	==============================================================================

#define RSC_Hostname		nDBaseSvcRscBase+1 
#define RSC_Username		nDBaseSvcRscBase+2
#define RSC_Password		nDBaseSvcRscBase+3
#define RSC_Database		nDBaseSvcRscBase+4

#endif
//	==============================================================================

