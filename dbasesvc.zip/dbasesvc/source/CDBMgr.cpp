//	==============================================================================
//	CDBMgr.cpp - Database Access Manager
//	------------------------------------------------------------------------------
//	Copyright �2011 Evolution Computing, Inc.
//	All rights reserved
//	==============================================================================

#include "fwkw.h"

#include "Winsock2.h"
#include "mysql.h"

IDBConnection* MakeDBConnection(WCHAR* pHost,WCHAR* pUser,WCHAR* pPWord,WCHAR* pDBName);

//	==============================================================================
//	Class definition
//	==============================================================================

class CDBMgr : public IMObject
{
public:
	CDBMgr(void);
	~CDBMgr(void);
	virtual void* Msg(MSGDISPATCH);
	void* OnDBConnect(MSGP);
public:
	UINT	nError;
	WCHAR	szError[MAX_PATH];
};

//	==============================================================================
//	Class factory
//	==============================================================================

DLLEXPORT IMObject* MakeDBSvc(void)
{
	pDBSvc = (IMObject*)new CDBMgr();
	return pDBSvc;
}

//	==============================================================================
//	Constructor
//	==============================================================================

CDBMgr::CDBMgr(void)
{
	hDBaseList = DbMakeList(NULL,FWK_DBASELIST,L"DBase List");
}

//	==============================================================================
//	Destructor
//	==============================================================================

CDBMgr::~CDBMgr(void)
{
}

//	==============================================================================
//	Variable length message receiver/dispatcher
//	==============================================================================

void* CDBMgr::Msg(MSGDISPATCH)
{
	switch(MSGID)
	{
	case MSG_DBaseConnect: return OnDBConnect(MPPTR);
	case MSG_DBaseErrorStg: return (void*)szError;
	case MSG_DBaseErrorNr: return (void*)nError;
	};

	return IM_RTN_IGNORED;
}

//	==============================================================================
//	Connect to a database
//	==============================================================================

void* CDBMgr::OnDBConnect(MSGP)
{
	MPARMPTR(MSGS_DBConnect*,pmsg);

	IDBConnection* hDBase = MakeDBConnection(pmsg->pHost,pmsg->pUser,pmsg->pPWord,pmsg->pDBName);
	nError = (UINT)hDBase->DBaseErrorNr();
	hSvc->SvcCopyW(szError,(WCHAR*)hDBase->DBaseErrorStg());
	if(nError==0)
		return hDBase;
	hDBase->Release();
	return NULL;
}

//	==============================================================================
