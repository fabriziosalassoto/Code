//	==============================================================================
//	CDBMgr.h - Database Access Manager
//	------------------------------------------------------------------------------
//	Copyright � 2009 Evolution Computing, Inc.
//	All rights reserved
//	==============================================================================

class CDBMgr : public IMObject
{
public:
	CDBMgr(void);
	~CDBMgr(void);
	virtual void* Msg(MSGDISPATCH);
	void* OnDBConnect(MSGP);
public:
	UINT	nError;
	WCHAR	szError[MAX_PATH];
};

//	==============================================================================
