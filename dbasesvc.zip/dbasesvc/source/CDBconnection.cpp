//	==============================================================================
//	CDBConnection.cpp - Database Connection Object
//	------------------------------------------------------------------------------
//	Copyright � 2008-2011 Evolution Computing, Inc.
//	All rights reserved
//	==============================================================================

#include "fwkw.h"

#include "Winsock2.h"
#include "mysql.h"

//	==============================================================================
//	Class definition
//	==============================================================================

class CDBConnection : public CDbObject
{
public:
	CDBConnection(WCHAR* pHost,WCHAR* pUser,WCHAR* pPWord,WCHAR* pDBName);
	~CDBConnection(void);
	virtual void* Msg(MSGDISPATCH);
	void* OnDBClose(void);
	void* OnDBUse(MSGP);
	void* OnDBaseGetCharSet(MSGP);
	void* OnDBaseSetCharSet(MSGP);

	void* OnDBQueryW(MSGP);
	void* OnDBQueryA(MSGP);
	void* OnDBQueryN(MSGP);

	void* OnDBGetNextRow(void);
	void* OnDBGetInsertId(void);

	void* OnDBGetColumnS(MSGP);
	void* OnDBGetColumnB(MSGP);
	void* OnDBGetColumnI(MSGP);
	void* OnDBColumnTitle(MSGP);

	void* OnDBBuildClear(void);
	void* OnDBBuildA(MSGP);
	void* OnDBBuildW(MSGP);
	void* OnDBBuildB(MSGP);
	void* OnDBBuildI(MSGP);
	void* OnDBBuildSend(void);

	void* CDBConnection::OnDBOAdd(MSGP); 
	void* OnDBOUpdate(MSGP);
	void* OnDBODelete(MSGP);
	void* OnDBOFind(MSGP);
	void* OnDBOSelect(MSGP);
	void* OnDBOSelectAll(MSGP);
	void* OnDBOGetRowData(MSGP);
	void* OnDBOCreateTable(MSGP);
	void* OnDBODeleteTable(MSGP);
	void* OnDBOBackup(MSGP);
	void* OnDBORestore(MSGP);
public:
	void* AccessError(void);
	void* GetResults(void);
public:
	MYSQL*		pConn;
	MYSQL_RES*	pResSet;
	MYSQL_ROW	row;
	MYSQL_FIELD* field;
	UINT		nAffected;
	UINT		nCols;
	UINT		nRows;
	UINT*		pColLens;

	UINT		nError;
	WCHAR		szError[MAX_PATH];
	
	UCHAR		szHost[MAX_PATH];
	UCHAR		szUser[MAX_PATH];
	UCHAR		szPWord[MAX_PATH];
	UCHAR		szDBName[MAX_PATH];

	MYSQL mysql;

	IArray*		hBfr;
	IStr*		hSQL;
};

//	==============================================================================
//	Class factory
//	==============================================================================

IDBConnection* MakeDBConnection(WCHAR* pHost,WCHAR* pUser,WCHAR* pPWord,WCHAR* pDBName)
{
	return (IDBConnection*) new CDBConnection(pHost,pUser,pPWord,pDBName);
}

//	==============================================================================
//	Constructor
//	==============================================================================

CDBConnection::CDBConnection(WCHAR* pHost,WCHAR* pUser,WCHAR* pPWord,WCHAR* pDBName)
		: CDbObject(hDBaseList,0)
{
	//	convert from Unicode
	hSvc->SvcFromUnicode(szHost,pHost,0);
	hSvc->SvcFromUnicode(szUser,pUser,0);
	hSvc->SvcFromUnicode(szPWord,pPWord,0);
	hSvc->SvcFromUnicode(szDBName,pDBName,0);

	//	allocate and initialize a connection structure

	mysql_library_init(0,NULL,NULL);

	pConn = mysql_init(&mysql);
	if(!pConn)
	{
		hSvc->SvcCopyW(szError,L"mysql_init failure");
		nError = -1;
		return;
	}

	//	make the real connection

	nError = 0;
	szError[0] = 0;
	if(mysql_real_connect(pConn,(const char*)szHost,(const char*)szUser,
		(const char*)szPWord,(const char*)szDBName,0,NULL,0)==NULL)
	{
		nError = mysql_errno(pConn);
		hSvc->SvcToUnicode(szError,(UCHAR*)mysql_error(pConn),0);
	}

	pResSet = NULL;
	hBfr = MakeArray(1,256,1);
	hSQL = MakeStr();
}

//	==============================================================================
//	Destructor
//	==============================================================================

CDBConnection::~CDBConnection(void)
{
	if(pResSet)
		mysql_free_result(pResSet);
	if(pConn)
		mysql_close(pConn);
	hBfr->Release();
	hSQL->Release();

	mysql_library_end();
}

//	==============================================================================
//	Variable length message receiver/dispatcher
//	==============================================================================

void* CDBConnection::Msg(MSGDISPATCH)
{
	switch(MSGID)
	{
	case MSG_DBaseClose: return OnDBClose();
	case MSG_DBaseUse: return OnDBUse(MPPTR);
	case MSG_DBaseErrorStg: return (void*)szError;
	case MSG_DBaseErrorNr: return (void*)nError;
	case MSG_DBaseClearError:
		nError = 0;
		szError[0] = 0;
		return IM_RTN_NOTHING;

	case MSG_DBaseGetCharSet: return OnDBaseGetCharSet(MPPTR);
	case MSG_DBaseSetCharSet: return OnDBaseSetCharSet(MPPTR);

	case MSG_DBaseQueryW: return OnDBQueryW(MPPTR);
	case MSG_DBaseQueryA: return OnDBQueryA(MPPTR);
	case MSG_DBaseQueryN: return OnDBQueryN(MPPTR);

	case MSG_DBaseGetNextRow: return OnDBGetNextRow();

	case MSG_DBaseGetColumnS: return OnDBGetColumnS(MPPTR);
	case MSG_DBaseGetColumnB: return OnDBGetColumnB(MPPTR);
	case MSG_DBaseGetColumnI: return OnDBGetColumnI(MPPTR);

	case MSG_DBaseGetInsertId: return OnDBGetInsertId();
	case MSG_DBaseNrAffected: return (void*)nAffected;
	case MSG_DBaseNrColumns: return (void*) nCols;
	case MSG_DBaseNrRows: return (void*) nRows;
	case MSG_DBaseColumnTitle: return OnDBColumnTitle(MPPTR);

	case MSG_DBaseBuildClear: return OnDBBuildClear();
	case MSG_DBaseBuildA: return OnDBBuildA(MPPTR);
	case MSG_DBaseBuildW: return OnDBBuildW(MPPTR);
	case MSG_DBaseBuildB: return OnDBBuildB(MPPTR);
	case MSG_DBaseBuildI: return OnDBBuildI(MPPTR);
	case MSG_DBaseBuildSend: return OnDBBuildSend();

	case MSG_DBaseOAdd: return OnDBOAdd(MPPTR);
	case MSG_DBaseOUpdate: return OnDBOUpdate(MPPTR);
	case MSG_DBaseODelete: return OnDBODelete(MPPTR);
	case MSG_DBaseOFind: return OnDBOFind(MPPTR);
	case MSG_DBaseOSelect: return OnDBOSelect(MPPTR);
	case MSG_DBaseOSelectAll: return OnDBOSelectAll(MPPTR);
	case MSG_DBaseOGetRowData: return OnDBOGetRowData(MPPTR);

	case MSG_DBaseOCreateTable: return OnDBOCreateTable(MPPTR);
	case MSG_DBaseODeleteTable: return OnDBODeleteTable(MPPTR);
	case MSG_DBaseOBackup: return OnDBOBackup(MPPTR);
	case MSG_DBaseORestore: return OnDBORestore(MPPTR);
	};

	return IM_RTN_IGNORED;
}

//	==============================================================================
//	Close this connection to a database server
//	==============================================================================

void* CDBConnection::OnDBClose(void)
{
	Release();
	return IM_RTN_NOTHING;
}

//	==============================================================================
//	specify new database to use
//	==============================================================================

void* CDBConnection::OnDBUse(MSGP)
{
	MPARMPTR(WCHAR*,pDBName);
	hSvc->SvcFromUnicode(szDBName,pDBName,0);

	return (void*)(mysql_select_db(pConn,(const char*)szDBName)==0);
}

//	==============================================================================
//	Returns the default character set name for the current connection.
//	==============================================================================

void* CDBConnection::OnDBaseGetCharSet(MSGP)
{
	return (void*)mysql_character_set_name(pConn);
}

//	==============================================================================
//	Set the default character set for the current connection.
//	==============================================================================

void* CDBConnection::OnDBaseSetCharSet(MSGP)
{
	MPARMPTR(WCHAR*, pCSName);
	UCHAR		szCSName[256];

	hSvc->SvcFromUnicode(szCSName,pCSName,0);

	// Return Values for mysql_set_character_set:  Zero for success. Nonzero if an error occurred.
	return MRTNVAL(!mysql_set_character_set(pConn, (char*)szCSName));
}


//	==============================================================================
//	access error
//	==============================================================================

void* CDBConnection::AccessError(void)
{
	nError = mysql_errno(pConn);
	hSvc->SvcToUnicode(szError,(UCHAR*)mysql_error(pConn),0);
	return IM_RTN_FALSE;
}

//	==============================================================================
//	Translate and send a Unicode string query
//	==============================================================================

void* CDBConnection::OnDBQueryW(MSGP)
{
	MPARMPTR(WCHAR*,pQuery);
	UCHAR szQuery[65536];
	hSvc->SvcFromUnicode(szQuery,pQuery,0);

	nError = 0;
	szError[0] = 0;
	if(pResSet)
		mysql_free_result(pResSet);
	pResSet = NULL;

	if(mysql_query(pConn,(const char*)szQuery))
		return AccessError();

	return GetResults();
}

//	==============================================================================
//	Send an ASCII string query
//	==============================================================================

void* CDBConnection::OnDBQueryA(MSGP)
{
	MPARMPTR(char*,szQuery);

	nError = 0;
	szError[0] = 0;
	if(pResSet)
		mysql_free_result(pResSet);
	pResSet = NULL;

	if(mysql_query(pConn,szQuery))
		return AccessError();

	return GetResults();
}

//	==============================================================================
//	Send an ASCII string query by character count
//	==============================================================================

void* CDBConnection::OnDBQueryN(MSGP)
{
	MPARMPTR(MSGS_DBaseQueryN*,pmsg);

	nError = 0;
	szError[0] = 0;
	if(pResSet)
		mysql_free_result(pResSet);
	pResSet = NULL;

	if(mysql_real_query(pConn,pmsg->pSQL,pmsg->nc))
		return AccessError();

	return GetResults();
}

//	==============================================================================
//	Get Results
//	==============================================================================

void* CDBConnection::GetResults(void)
{
	//	free any old result set
	if(pResSet)
	{
		mysql_free_result(pResSet);
		pResSet = NULL;
	}

	//	was there an error?
	if(szError[0]!=0)
		return IM_RTN_FALSE;

	//	store query results
	nAffected = 0;
	pResSet = mysql_store_result(pConn);
	if(!pResSet)
	{
		UINT nFieldCount = mysql_field_count(pConn);
		if(nFieldCount)
		{
			AccessError();
			return IM_RTN_FALSE;
		}
		//	valid query has no result set
		{	
			nRows = nCols = 0;
			nAffected = mysql_affected_rows(pConn);
			return IM_RTN_TRUE;
		}
	}
	
	//	valid result set
	nCols = mysql_num_fields(pResSet);
	nRows = mysql_num_rows(pResSet);
	return IM_RTN_TRUE;
}

//	==============================================================================
//	Get Next Row - call until NULL is returned
//	==============================================================================

void* CDBConnection::OnDBGetNextRow(void)
{
	if(!pResSet)
		return NULL;

	//	get next row
	row = mysql_fetch_row(pResSet);
	if(!row)
	{
		//	no more rows in result set
		mysql_free_result(pResSet);
		pResSet = NULL;
		return IM_RTN_FALSE;
	}
	pColLens = (UINT*)mysql_fetch_lengths(pResSet);

	//	we have an array of nCols ASCIIZ strings (char**)
	return IM_RTN_TRUE;
}

//	==============================================================================
//	Get Column Data by Nr: IStr text string
//	==============================================================================

void* CDBConnection::OnDBGetColumnS(MSGP)
{
	MPARMPTR(MSGS_DBaseGetColumnS*, pmsg);

	if(!pResSet)
		return NULL;
	if(!row)
		return NULL;
	if(pmsg->ixCol >= nCols)
		return NULL;

	if(row[pmsg->ixCol])	// might be NULL pointer
	{
		if(pmsg->pStg)
			pmsg->pStg->StrSetTextA((UCHAR*)row[pmsg->ixCol]);
		else
			pmsg->pStg = MakeStr((CHAR*)row[pmsg->ixCol]);
		return pmsg->pStg;
	}
	return NULL;
}

//	==============================================================================
//	Get Column Data by Nr: IArray binary data array
//	==============================================================================

void* CDBConnection::OnDBGetColumnB(MSGP)
{
	MPARMPTR(MSGS_DBaseGetColumnB*,pmsg);

	if(!pResSet)
		return NULL;
	if(!row)
		return NULL;
	if(pmsg->ixCol >= nCols)
		return NULL;

	if(row[pmsg->ixCol])	// might be NULL pointer
	{
		UINT nBytes = pColLens[pmsg->ixCol];
		UCHAR* pData = (UCHAR*)row[pmsg->ixCol];

		if(pmsg->hArray)
		{
			pmsg->hArray->AryEmpty();
			pmsg->hArray->AryAppend(pData,nBytes);
		}
		else
			pmsg->hArray = MakeArrayCopy(pData,nBytes);
		return pmsg->hArray;
	}
	return NULL;
}

//	==============================================================================
//	Get Image object from Column by Nr
//	==============================================================================

void* CDBConnection::OnDBGetColumnI(MSGP)
{
	MPARMPTR(MSGS_DBaseGetColumnI*,pmsg);

	if(!pResSet)
		return (void*)NULL;
	if(!row)
		return (void*)NULL;
	if(pmsg->ixCol >= nCols)
		return (void*)NULL;

	if(row[pmsg->ixCol])	// might be NULL pointer
	{
		UINT nBytes = pColLens[pmsg->ixCol];
		char* pData = row[pmsg->ixCol];

		// TODO: Implement hImage logic 

		return pmsg->hImage;
	}
	return NULL;
}

//	==============================================================================
//	//	Get Column Title by Nr: IStr text string
//	==============================================================================

void* CDBConnection::OnDBColumnTitle(MSGP)
{
	MPARMPTR(MSGS_DBaseColumnTitle*,pmsg);

	if(!pResSet)
		return NULL;
	if(pmsg->ixCol >= nCols)
		return NULL;

	mysql_field_seek(pResSet,pmsg->ixCol);
	field = mysql_fetch_field(pResSet);

	if(pmsg->pStg)
		pmsg->pStg->StrSetTextA((UCHAR*)field->name);
	else
		pmsg->pStg = MakeStr((CHAR*)field->name);

	return pmsg->pStg;
}

//	==============================================================================
//	Get Auto-insert ID assigned by latest query, if any
//	==============================================================================

void* CDBConnection::OnDBGetInsertId(void)
{
	return (void*)mysql_insert_id(pConn);
}

//	==============================================================================
//	clear string query build
//	==============================================================================

void* CDBConnection::OnDBBuildClear(void)
{
	hBfr->AryEmpty();
	return IM_RTN_NOTHING;
}

//	==============================================================================
//	send encoded query
//	==============================================================================

void* CDBConnection::OnDBBuildSend(void)
{
	return MRTNVAL(((IDBConnection*)this)->DBaseQueryA((char*)hBfr->AryBfr()));
}

//	==============================================================================
//	append ASCII to string query build
//	==============================================================================

void* CDBConnection::OnDBBuildA(MSGP)
{
	MPARMPTR(char*,pText);
	UINT nc = 0;

	if(pText)
		nc = (UINT)strlen(pText);
	if(nc)
	{
		hBfr->AryAppend(pText,nc);
	}
	return hBfr->AryBfr();
}

//	==============================================================================
//	append Unicode to string query build
//	==============================================================================

void* CDBConnection::OnDBBuildW(MSGP)
{
	MPARMPTR(WCHAR*,pText);
	UINT nc = 0;

	if(pText)
		nc = (UINT)hSvc->SvcLengthW(pText);
	if(nc)
	{
		UINT at = (UINT)hBfr->AryCount();
		hBfr->AryAddCount(nc);
		UCHAR* pDest = (UCHAR*)hBfr->AryItemPtr(at);
		hSvc->SvcFromUnicode(pDest,pText,nc);
	}
	return hBfr->AryBfr();
}

//	==============================================================================
//	encode and append binary data to string query as a quoted escaped string
//	==============================================================================

void* CDBConnection::OnDBBuildB(MSGP)
{
	MPARMPTR(MSGS_DBaseBuildB*,pmsg);

	if(pmsg->nData)
	{
		hBfr->AryGrowFor(pmsg->nData+pmsg->nData+4);
		hBfr->AryAppend(L"'",1);
		char* pDest = (char*)hBfr->AryBfr() + hBfr->AryCount();
		if(pConn)
			pmsg->nData = mysql_real_escape_string(pConn, pDest,pmsg->pData,pmsg->nData);
		else
			pmsg->nData = mysql_escape_string(pDest,pmsg->pData,pmsg->nData);
		hBfr->AryAddCount(pmsg->nData);
		hBfr->AryAppend(L"'",1);
	}
	return hBfr->AryBfr();
}

//	==============================================================================
//	encode and append image binary data
//	==============================================================================

struct IMGHDR
{
	int			sz;			// sizeof(IMGHDR)
	int			wid;		// nr of columns (in pixels)
	int			hgt;		// nr of lines (in pixels)
	int			hotx;		// icon hotspot
	int			hoty;
	UINT		flags;		// bit 1 = 1st pixel is top left, else bottom left
};

void* CDBConnection::OnDBBuildI(MSGP)
{
	MPARMPTR(IImage*,hImage);
	if(!hImage)
		return hBfr->AryBfr();

	IMGINFO ii = *((IMGINFO*)hImage->ImgInfo());
	IMGHDR ih;
	ih.sz = sizeof(IMGHDR);
	ih.wid = ii.wid;
	ih.hgt = ii.hgt;
	ih.hotx = ii.hoty;
#if _IMGTOPFIRST
	ih.flags = (int)1;
#else
	ih.flags = (int)0;
#endif

	UINT nData = sizeof(ih)+ii.nPixBytes;

	UINT at = hBfr->AryCount();
	hBfr->AryGrowFor(nData+nData+4);
	hBfr->AryAppend(L"'",1);

	char* pDest = (char*)hBfr->AryItemPtr(at);
	nData = mysql_escape_string(pDest,(char*)&ih,sizeof(ih));
	pDest += nData;
	nData = mysql_escape_string(pDest,(char*)ii.pBits,ii.nPixBytes);

	hBfr->AryAddCount(nData);
	hBfr->AryAppend(L"'",1);

	return hBfr->AryBfr();
}


//	==============================================================================
//	DBRow objects: add row to table
//	==============================================================================
void* CDBConnection::OnDBOAdd(MSGP) 
{
	MPARMPTR(IDBRow*,hDO);

	nError = 0;
	szError[0] = 0;

	//	prepare SQL statement

	hSQL->StrSetTextW(L"INSERT INTO ");
	hSQL->StrAppendW(hDO->DBaseOTableName());
	hSQL->StrAppendW(L" (");

	UINT nrCols = hDO->DBaseONrCols();
	//	append fieldnames
	for(UINT ix=1;ix<=nrCols;ix++)
	{
		hSQL->StrAppendW(hDO->DBaseOColName(ix));
		if(ix < nrCols)
			hSQL->StrAppendW(L",");
	}
	hSQL->StrAppendW(L") VALUES (");
	//	append new values
	for(UINT ix=1;ix<=nrCols;ix++)
	{
		hSQL->StrAppendW(L" '");
		hSQL->StrAppendW(hDO->DBaseOText(ix));
		hSQL->StrAppendW(L"'");
		if(ix < nrCols)
			hSQL->StrAppendW(L",");
	}
	hSQL->StrAppendW(L")");

	//	send SQL query
	if(((IDBConnection*)this)->DBaseQueryW(hSQL->StrTextPtr()))
	{
		if(((IDBConnection*)this)->DBaseNrAffected()==0)
		{
			//	add failed
			nError = mysql_errno(pConn);
			hSvc->SvcToUnicode(szError,(UCHAR*)mysql_error(pConn),0);
			return IM_RTN_FALSE;
		}
	}
	else
	{
		//	add failed
		return IM_RTN_FALSE;
	}

	return IM_RTN_TRUE;
}

//	==============================================================================
//	DBRow objects: update row in table
//	==============================================================================
void* CDBConnection::OnDBOUpdate(MSGP)
{
	MPARMPTR(IDBRow*,hDO);

	nError = 0;
	szError[0] = 0;

	//	prepare SQL statement

	hSQL->StrSetTextW(L"UPDATE ");
	hSQL->StrAppendW(hDO->DBaseOTableName());
	hSQL->StrAppendW(L" SET ");

	UINT nrCols = hDO->DBaseONrCols();

	//	append fieldnames = 'value'	items
	for(UINT ix=1;ix<=nrCols;ix++)
	{
		hSQL->StrAppendW(hDO->DBaseOColName(ix));
		hSQL->StrAppendW(L" = '");
		hSQL->StrAppendW(hDO->DBaseOText(ix));
		hSQL->StrAppendW(L"'");
		if(ix < nrCols)
			hSQL->StrAppendW(L",");
	}

	//	append where clause
	hSQL->StrAppendW(L" WHERE ");
	UINT ix = hDO->DBaseOPrimaryKeyIdx();
	hSQL->StrAppendW(hDO->DBaseOColName(ix));
	hSQL->StrAppendW(L" = '");
	hSQL->StrAppendW(hDO->DBaseOText(ix));
	hSQL->StrAppendW(L"'");

	//	send SQL query
	if(((IDBConnection*)this)->DBaseQueryW(hSQL->StrTextPtr()))
	{
		if(((IDBConnection*)this)->DBaseNrAffected()==0)
		{
			//	update failed
			nError = mysql_errno(pConn);
			hSvc->SvcToUnicode(szError,(UCHAR*)mysql_error(pConn),0);
			return IM_RTN_FALSE;
		}
	}
	else
	{
		//	update failed
		return IM_RTN_FALSE;
	}

	return IM_RTN_TRUE;
}

//	==============================================================================
//	DBRow objects: delete row from table
//	==============================================================================
void* CDBConnection::OnDBODelete(MSGP)
{
	MPARMPTR(IDBRow*,hDO);

	nError = 0;
	szError[0] = 0;

	//	prepare SQL statement

	hSQL->StrSetTextW(L"DELETE FROM ");
	hSQL->StrAppendW(hDO->DBaseOTableName());

	//	append where clause
	hSQL->StrAppendW(L" WHERE ");
	UINT ix = hDO->DBaseOPrimaryKeyIdx();
	hSQL->StrAppendW(hDO->DBaseOColName(ix));
	hSQL->StrAppendW(L" = '");
	hSQL->StrAppendW(hDO->DBaseOText(ix));
	hSQL->StrAppendW(L"'");

	//	send SQL query
	if(!((IDBConnection*)this)->DBaseQueryW(hSQL->StrTextPtr()))
	{
		//	delete failed
		return IM_RTN_FALSE;
	}

	return IM_RTN_TRUE;
}

//	==============================================================================
//	DBRow objects: find row data from primary key value
//	==============================================================================
void* CDBConnection::OnDBOFind(MSGP)
{
	MPARMPTR(IDBRow*,hDO);

	nError = 0;
	szError[0] = 0;

	//	prepare SQL statement

	hSQL->StrSetTextW(L"SELECT * FROM ");
	hSQL->StrAppendW(hDO->DBaseOTableName());

	//	append where clause
	hSQL->StrAppendW(L" WHERE ");
	UINT ix = hDO->DBaseOPrimaryKeyIdx();
	hSQL->StrAppendW(hDO->DBaseOColName(ix));
	hSQL->StrAppendW(L" = '");
	hSQL->StrAppendW(hDO->DBaseOText(ix));
	hSQL->StrAppendW(L"'");

	//	send SQL query
	if(!((IDBConnection*)this)->DBaseQueryW(hSQL->StrTextPtr()))
	{
		//	find failed
		return IM_RTN_FALSE;
	}

	//	get first row data to hDO
	if(((IDBConnection*)this)->DBaseGetNextRow())
		return MRTNVAL(((IDBConnection*)this)->DBaseOGetRowData(hDO));

	//	get row failed
	return IM_RTN_FALSE;
}

//	==============================================================================
//	DBRow objects: get all columns of current row data resulting from query
//	==============================================================================

void* CDBConnection::OnDBOGetRowData(MSGP)
{
	MPARMPTR(IDBRow*,hDO);

	UINT nrCols = hDO->DBaseONrCols();

	for(UINT ix=1;ix<=nrCols;ix++)
	{
		IStr* hStr = hDO->DBaseOStr(ix);
		((IDBConnection*)this)->DBaseGetColumnS(ix-1,hStr);
		if(hDO->DBaseOColHint(ix) & DBOH_DATEONLY)
		{
			//	trim TIMESTAMP from yyyy-mm-dd hh:mm to only yy-mm-dd
			if(hStr->StrLength() > 10)
				hStr->StrSetCount(10);
		}
	}

	return IM_RTN_TRUE;
}

//	==============================================================================
//	DBRow objects: select rows based on non-empty fields
//	==============================================================================

void* CDBConnection::OnDBOSelect(MSGP)
{
	MPARMPTR(MSGS_DBaseOSelect*,pmsg);
	IDBRow* hDO = pmsg->hDO;

	nError = 0;
	szError[0] = 0;

	//	prepare SQL statement

	UINT nrCols = hDO->DBaseONrCols();
	bool firstTest = true;

	//	append fieldnames = 'value'	tests
	for(UINT ix=1;ix<=nrCols;ix++)
	{
		IStr* hVal = hDO->DBaseOStr(ix);
		WCHAR* pFieldName = hDO->DBaseOColName(ix);

		if(hVal->StrLength())
		{
			if(firstTest)
			{
				hSQL->StrSetTextW(L"SELECT * FROM ");
				hSQL->StrAppendW(hDO->DBaseOTableName());
				hSQL->StrAppendW(L" WHERE ");
			}
			else
			{
				hSQL->StrAppendW(L" AND ");
			}
			hSQL->StrAppendW(pFieldName);
			hSQL->StrAppendW(L" REGEXP '");
			hSQL->StrAppendW(hVal->StrTextPtr());
			hSQL->StrAppendW(L"'");
			firstTest = false;
		}
	}

	//	no query?
	if(firstTest)
		return NULL;

	//	send SQL query
	if(!((IDBConnection*)this)->DBaseQueryW(hSQL->StrTextPtr()))
	{
		//	select failed
		return NULL;
	}

	//	want all rows returned now?
	if(!pmsg->fReturnRows)
		return IM_RTN_TRUE;

	//	create results array
	UINT nrRows = (UINT)((IDBConnection*)this)->DBaseNrRows();
	IArray* hResults = MakeObjArray(nrRows,true);

	//	get all products data
	while(((IDBConnection*)this)->DBaseGetNextRow())
	{
		//	create object for current row
		IDBRow* hObj = pmsg->hDO->DBaseOMake();
		hResults->AryAppend(&hObj,1);
		//	get all row data to hDO
		((IDBConnection*)this)->DBaseOGetRowData(hObj);
	}

	return hResults;
}

//	==============================================================================
//	DBRow objects: select all rows
//	==============================================================================
void* CDBConnection::OnDBOSelectAll(MSGP)
{
	MPARMPTR(MSGS_DBaseOSelectAll*,pmsg);
	IDBRow* hDO = pmsg->hDO;

	nError = 0;
	szError[0] = 0;

	//	prepare SQL statement

	hSQL->StrSetTextW(L"SELECT * FROM ");
	hSQL->StrAppendW(hDO->DBaseOTableName());

	//	send SQL query
	if(!((IDBConnection*)this)->DBaseQueryW(hSQL->StrTextPtr()))
	{
		//	select failed
		return NULL;
	}

	//	want all rows returned now?
	if(!pmsg->fReturnRows)
		return IM_RTN_TRUE;

	//	create results array
	UINT nrRows = (UINT)((IDBConnection*)this)->DBaseNrRows();
	IArray* hResults = MakeObjArray(nrRows,true);

	//	get all products data
	while(((IDBConnection*)this)->DBaseGetNextRow())
	{
		//	create object for current row
		IDBRow* hObj = hDO->DBaseOMake();
		hResults->AryAppend(&hObj,1);
		//	get all row data to hDO
		((IDBConnection*)this)->DBaseOGetRowData(hObj);
	}

	return hResults;
}

//	==============================================================================
//	DBRow objects: create table in database
//	==============================================================================
void* CDBConnection::OnDBOCreateTable(MSGP)
{
	MPARMPTR(IDBRow*,hDO);

	nError = 0;
	szError[0] = 0;

	//	prepare SQL statement

	hSQL->StrSetTextW(L"CREATE TABLE ");
	hSQL->StrAppendW(hDO->DBaseOTableName());
	hSQL->StrAppendW(L" ( ");

	UINT nrCols = hDO->DBaseONrCols();
	//	append fieldnames
	for(UINT ix=1;ix<=nrCols;ix++)
	{
		hSQL->StrAppendW(hDO->DBaseOColName(ix));
		hSQL->StrAppendW(L" ");
		hSQL->StrAppendW(hDO->DBaseOColDef(ix));
		hSQL->StrAppendW(L",");
	}

	hSQL->StrAppendW(L"PRIMARY KEY (");
	UINT ix = hDO->DBaseOPrimaryKeyIdx();
	hSQL->StrAppendW(hDO->DBaseOColName(ix));
	hSQL->StrAppendW(L" ) ) ENGINE=InnoDB");

	//	send SQL query
	if(!((IDBConnection*)this)->DBaseQueryW(hSQL->StrTextPtr()))
	{
		//	create failed
		return IM_RTN_FALSE;
	}

	return IM_RTN_TRUE;
}

//	==============================================================================
//	DBRow objects: delete table from database
//	==============================================================================
void* CDBConnection::OnDBODeleteTable(MSGP)
{
	MPARMPTR(IDBRow*,hDO);

	nError = 0;
	szError[0] = 0;

	//	prepare SQL statement

	hSQL->StrSetTextW(L"DROP TABLE ");
	hSQL->StrAppendW(hDO->DBaseOTableName());

	//	send SQL query
	if(!((IDBConnection*)this)->DBaseQueryW(hSQL->StrTextPtr()))
	{
		//	delete failed
		return IM_RTN_FALSE;
	}

	return IM_RTN_TRUE;
}

//	==============================================================================
//	DBRow objects: backup table to xml file
//	==============================================================================
void* CDBConnection::OnDBOBackup(MSGP)
{
	MPARMPTR(MSGS_DBaseOBackup*,pmsg);
	IDBRow* hDO = pmsg->hDO;
	IStr* hStr = pmsg->hFile;

	nError = 0;
	szError[0] = 0;

	hStr->StrAppendW(L"\r\n  <Table name=\"");
	hStr->StrAppendW(hDO->DBaseOTableName());
	hStr->StrAppendW(L"\">\r\n\r\n");

	UINT nrCols = hDO->DBaseONrCols();

	//	write field definitions (schema)
	hStr->StrAppendW(L"    <def>\r\n");
	//	append fieldnames and defs
	for(UINT ix=1;ix<=nrCols;ix++)
	{
		hStr->StrAppendW(L"      <item name=\"");
		hStr->StrAppendW(hDO->DBaseOColName(ix));
		hStr->StrAppendW(L"\">\"");
		hStr->StrAppendW(hDO->DBaseOColDef(ix));
		hStr->StrAppendW(L"\"</item>\r\n");
	}
	hStr->StrAppendW(L"    </def>\r\n\r\n");

	//	get all products records
	hSQL->StrSetTextW(L"SELECT * FROM ");
	hSQL->StrAppendW(hDO->DBaseOTableName());
	if(!((IDBConnection*)this)->DBaseQueryW(hSQL->StrTextPtr()))
	{
		return IM_RTN_FALSE;
	}

	//	get all products data
	while(((IDBConnection*)this)->DBaseGetNextRow())
	{
		//	get current row data
		((IDBConnection*)this)->DBaseOGetRowData(hDO);

		hStr->StrAppendW(L"    <row>\r\n");

		//	append fieldnames and values
		for(UINT ix=1;ix<=nrCols;ix++)
		{
			hStr->StrAppendW(L"      <item name=\"");
			hStr->StrAppendW(hDO->DBaseOColName(ix));
			hStr->StrAppendW(L"\">\"");
			hStr->StrAppendW(hDO->DBaseOText(ix));
			hStr->StrAppendW(L"\"</item>\r\n");
		}
		hStr->StrAppendW(L"    </row>\r\n\r\n");
	}

	//	end of table marker
	hStr->StrAppendW(L"  </Table>\r\n");

	return IM_RTN_TRUE;
}

//	==============================================================================
//	DBRow objects: restore table from xml file
//	==============================================================================
void* CDBConnection::OnDBORestore(MSGP)
{
	MPARMPTR(MSGS_DBaseORestore*,pmsg);
	IDBRow* hDO = pmsg->hDO;
	IStr* hStr = pmsg->hFile;

	nError = -1;
	int error = 0;
	hSvc->SvcCopyW(szError,L"Error - table data not found in xml file");

	UINT nrCols = hDO->DBaseONrCols();

	IStr* hMatch = MakeStr(L"<Table name=\"");
	hMatch->StrAppendW(hDO->DBaseOTableName());
	hMatch->StrAppendW(L"\">");
	IStr* hTemp = MakeStr();

	//	skip until match on table name
	hStr->StrScanStart();
	if(hStr->StrSkipUntil(hMatch->StrTextPtr()))
	{
		while(!error)
		{
			if(!hStr->StrScanMatch(L"</Table>")) // * flags end of table
			{
				//	ignore field definitions (table schema)
				if(hStr->StrScanMatch(L"<def>"))
				{
					hStr->StrSkipUntil(L"</def>");
				}

				// start a row here unless end of table
				while(hStr->StrScanMatch(L"<row>"))
				{
					if(!error)
					{
						//	process each field
						while(!hStr->StrScanMatch(L"</row>"))
						{
							if(hStr->StrScanAtEOS(true)){error = true;break;}

							error |= !hStr->StrScanMatch(L"<item name=\"");
							error |= !hStr->StrScanUntil(L"\">",&hTemp);
							UINT ixField = hDO->DBaseOColFind(hTemp->StrTextPtr());
							IStr* hVal = hDO->DBaseOStr(ixField);
							error |= !hStr->StrScanQText(&hVal);
							error |= !hStr->StrScanMatch(L"</item>");
						}
					}
			
					if(error)
					{
						//	goto better than code duplication in this case
						goto finished;
					}

					//	append record to end of products table
					if(!((IDBConnection*)this)->DBaseOAdd(hDO))
					{
						//	goto better than code duplication in this case
						goto finished;
					}	
				}
			}
			else // end of table definition
				break;
		}

		//	parsing error?
		if(error)
		{
			hTemp = MakeStr(L"Error parsing ");
			hTemp->StrAppendW(hDO->DBaseOTableName());
			hTemp->StrAppendW(L" table for Restore");
			hSvc->SvcCopyW(szError,hTemp->StrTextPtr());
		}
		else
			nError = 0;
	}

finished:
	hTemp->Release();
	hMatch->Release();
	return (void*)!nError;
}

//	==============================================================================
