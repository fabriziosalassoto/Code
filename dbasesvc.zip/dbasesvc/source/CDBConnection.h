//	==============================================================================
//	CDBConnection.h - Database Connection Object
//	------------------------------------------------------------------------------
//	Copyright � 2009 Evolution Computing, Inc.
//	All rights reserved
//	==============================================================================

class CDBConnection : public CDbObject
{
public:
	CDBConnection(WCHAR* pHost,WCHAR* pUser,WCHAR* pPWord,WCHAR* pDBName);
	~CDBConnection(void);
	virtual void* Msg(MSGDISPATCH);
	void* OnDBClose(void);
	void* OnDBUse(MSGP);
	void* OnDBQueryW(MSGP);
	void* OnDBQueryA(MSGP);
	void* OnDBQueryN(MSGP);
	void* OnDBGetNextRow(void);
	void* OnDBGetColumnA(MSGP);
	void* OnDBGetColumnW(MSGP);
	void* OnDBGetColumnB(MSGP);
	void* OnDBGetColumnI(MSGP);
	void* OnDBGetColTitleW(MSGP);
	void* OnDBGetInsertId(void);
//
	void* OnDBBuildClear(void);
	void* OnDBBuildA(MSGP);
	void* OnDBBuildW(MSGP);
	void* OnDBBuildB(MSGP);
	void* OnDBBuildI(MSGP);
	void* OnDBBuildSend(void);
public:
	void* AccessError(void);
	void* GetResults(void);
public:
	MYSQL*		pConn;
	MYSQL_RES*	pResSet;
	MYSQL_ROW	row;
	MYSQL_FIELD* field;
	UINT		nAffected;
	UINT		nCols;
	UINT		nRows;
	UINT*		pColLens;

	UINT		nError;
	WCHAR		szError[MAX_PATH];
	
	char		szHost[MAX_PATH];
	char		szUser[MAX_PATH];
	char		szPWord[MAX_PATH];
	char		szDBName[MAX_PATH];

	IMObject*	hBfr;
};

//	==============================================================================
