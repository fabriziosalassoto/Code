/*****************************************************************************************
/* Author: Fabrizio Salas Soto															 *
/*																						 *
/* Version: 1.0 / July 2015																 *
/*																						 *
/* Notes: The purpose of this example is to demonstrate with practical approach			 *
/* how to implement a small application using the EVTK Library to join a few concepts	 *
/* like Database usage, graphical screen use, communication among apps, threading, etc.	 *
/*																					     *
/*****************************************************************************************/
#include "fwkw.h"

class inventorycontrol : public CControl
{
public:
	inventorycontrol(IControl* hParent,CTRLLOC* pLocn);
	~inventorycontrol(void);
	virtual void* Msg(MSGDISPATCH);	
	void* OnDraw(void);	
	void* OnDG2ItemChanged(MSGP);

public:
	ILabelCtl*		LblCompanyName;
	ILabelCtl*		LblCompanyDetails;
	ILabelCtl*      LblDate;
		
	IDataGridCtl*	GrdItemsToBill;	

	IButtonCtl*     BtnAdd;
	IButtonCtl*     BtnErase;
	IButtonCtl*     BtnEdit;
	IButtonCtl*     BtnSave;
};


IControl* MakeMyCtrl(IControl* hParent,CTRLLOC* pLocn)
{
	return (IControl*) new inventorycontrol(hParent,pLocn);
}

static UINT ctrlid = 100;

inventorycontrol::inventorycontrol(IControl* hparent,CTRLLOC* pLocn) : CControl(hparent,ctrlid){
	Locn = *pLocn;
	nBkgndColor = COLOR_APPWORKSPACE; // COLOR_CTRL_BKGND_SOFT;
	CTRLLOC PBLocn = {PARENT_RELATIVE,{20,40,520,50},0}; //Left, Top, Width, Height
	
	CTRLLOC LblLocn1 = {PARENT_RELATIVE,{20,50,110,25},0};
	LblCompanyName = (ILabelCtl*)MakeLabelCtl((IControl*)this,1,&LblLocn1,
		             TEXT("[company website]"),false,false,false);		

	CTRLLOC LblLocn2 = {PARENT_RELATIVE,{20,90,110,25},0};
	LblCompanyDetails = (ILabelCtl*)MakeLabelCtl((IControl*)this,2,&LblLocn2,
		             TEXT("1912 Wayside Lane\n\rSan Francisco, CA 94108\n\r(415) 123 4567\n\rinfo@bloomies.com"),false,false,false);	

	CTRLLOC LblLocn3 = {PARENT_RELATIVE,{825,90,100,25},0};
	LblDate = (ILabelCtl*)MakeLabelCtl((IControl*)this,3,&LblLocn3,
		             TEXT("DATE: April-26, 2013"),false,false,false);	

	

									 //  Left, Top,Width,Height
	CTRLLOC GridLocn2 = {PARENT_RELATIVE,{20,190,985,630},0};
	GrdItemsToBill = MakeDataGrid((IControl*)this,12,&GridLocn2);
	GrdItemsToBill->CtlSetNotify(this);
	GrdItemsToBill->DGAddColumns(0,6);
	GrdItemsToBill->DGAddRows(0,20);
	GrdItemsToBill->DGSetColumnWidth(0,100);	
	GrdItemsToBill->DGSetColumnWidth(1,100);
	GrdItemsToBill->DGSetColumnWidth(2,385);
	GrdItemsToBill->DGSetColumnWidth(3,125);
	GrdItemsToBill->DGSetColumnWidth(4,125);
	GrdItemsToBill->DGSetColumnWidth(5,125);
	
	GrdItemsToBill->DGSetItemText(0,0,TEXT("INVOICE NBR"));
	GrdItemsToBill->DGSetItemReadOnly(0,0,true);
	GrdItemsToBill->DGSetItemGreyBkgnd(0,0,true);

	GrdItemsToBill->DGSetItemText(0,1,TEXT("DATE"));
	GrdItemsToBill->DGSetItemReadOnly(0,1,true);
	GrdItemsToBill->DGSetItemGreyBkgnd(0,1,true);

	GrdItemsToBill->DGSetItemText(0,2,TEXT("CUSTOMER"));
	GrdItemsToBill->DGSetItemReadOnly(0,2,true);
	GrdItemsToBill->DGSetItemGreyBkgnd(0,2,true);

	GrdItemsToBill->DGSetItemText(0,3,TEXT("AMOUNT"));
	GrdItemsToBill->DGSetItemReadOnly(0,3,true);
	GrdItemsToBill->DGSetItemGreyBkgnd(0,3,true);

	GrdItemsToBill->DGSetItemText(0,4,TEXT("TAX"));
	GrdItemsToBill->DGSetItemReadOnly(0,4,true);
	GrdItemsToBill->DGSetItemGreyBkgnd(0,4,true);

	GrdItemsToBill->DGSetItemText(0,5,TEXT("TOTAL"));
	GrdItemsToBill->DGSetItemReadOnly(0,5,true);
	GrdItemsToBill->DGSetItemGreyBkgnd(0,5,true);
	GrdItemsToBill->CtlSetSelColors(COLOR_WHITE,COLOR_BLACK);	
	
	CTRLLOC ButtonLocn1 = {PARENT_RELATIVE,{20,645,250,670},0};
	BtnAdd = MakeButtonCtl((IControl*)this,2,&ButtonLocn1, BTN3D,0,
	TEXT("ADD PRODUCT"),NULL,false,false);
	BtnAdd->CtlSetBkColor(COLOR_BLUE);
	BtnAdd->CtlSetTxColor(COLOR_WHITE);
	BtnAdd->CtlSetNotify(this);

	CTRLLOC ButtonLocn2 = {PARENT_RELATIVE,{260,645,490,670},0};
	BtnEdit = MakeButtonCtl((IControl*)this,2,&ButtonLocn2, BTN3D,0,
	TEXT("EDIT PRODUCT"),NULL,false,false);
	BtnEdit->CtlSetBkColor(COLOR_BLUE);
	BtnEdit->CtlSetTxColor(COLOR_WHITE);
	BtnEdit->CtlSetNotify(this);

	CTRLLOC ButtonLocn3 = {PARENT_RELATIVE,{500,645,740,670},0};
	BtnErase = MakeButtonCtl((IControl*)this,2,&ButtonLocn3, BTN3D,0,
	TEXT("ERASE PRODUCT"),NULL,false,false);
	BtnErase->CtlSetBkColor(COLOR_BLUE);
	BtnErase->CtlSetTxColor(COLOR_WHITE);
	BtnErase->CtlSetNotify(this);

	CTRLLOC ButtonLocn4 = {PARENT_RELATIVE,{750,645,980,670},0};
	BtnSave = MakeButtonCtl((IControl*)this,2,&ButtonLocn4, BTN3D,0,
	TEXT("SAVE DATA"),NULL,false,false);
	BtnSave->CtlSetBkColor(COLOR_BLUE);
	BtnSave->CtlSetTxColor(COLOR_WHITE);
	BtnSave->CtlSetNotify(this);
}

inventorycontrol::~inventorycontrol(void){}


void* inventorycontrol::OnDG2ItemChanged(MSGP)
{
	MPARMPTR(MSGS_DGItemChanged*,pmsg);
	IMObject* hDGrid2 = pmsg->hDGrid2;
	UINT nSelRow = pmsg->nSelRow;
	UINT nSelCol = pmsg->nSelCol;

	UINT oid1 = (int)GrdItemsToBill->DbId();	
	return IM_RTN_NOTHING;
}

void* inventorycontrol::Msg(MSGDISPATCH)
{
	switch(MSGID)
	{
		case MSG_DbOType:return MRTNVAL(FWK_CTRLCLASS+CTRL_CONTAINER);
		case MSG_CtlDraw: return OnDraw();
		case MSG_WinClose:		
			return IM_RTN_NOTHING;
	}	
	return MSGFWDBASE(CControl,MSGID);
}

void* inventorycontrol::OnDraw(void)
{
	if(!fVisible || !fSized)
		return IM_RTN_NOTHING;
	
	hDraw->IDrawFColor(nBkgndColor);
	hDraw->IDrawFRectP(&CRect);

	IControl* hCtrl = (IControl*)DbFirstSL();
	while(hCtrl && (hCtrl != (IControl*)hSLEnd))
	{
		hCtrl->CtlDraw();
		hCtrl = (IControl*)hCtrl->DbNextMain();
	}
	
	hDraw->IDrawTColor(COLOR_BLUE);
	hDraw->IDrawSetFont(TEXT("Arial.ttf"),36,0,true,true);
	hDraw->IDrawText(25,43,TEXT("COMPANY NAME"));

	hDraw->IDrawTColor(COLOR_RED);
	hDraw->IDrawSetFont(TEXT("Arial.ttf"),50,0,true,true);
	hDraw->IDrawText(750,50,TEXT("INVENTORY"));
		
	hDraw->IDrawLColor(COLOR_3DDKSHADOW);
	hDraw->IDrawDLine(20,80,980,80);	

	hDraw->IDrawImgRefresh(&CRect);
	return IM_RTN_NOTHING;
}