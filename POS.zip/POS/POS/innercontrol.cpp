/*****************************************************************************************
/* Author: Fabrizio Salas Soto															 *
/*																						 *
/* Version: 1.0 / July 2015																 *
/*																						 *
/* Notes: The purpose of this example is to demonstrate with practical approach			 *
/* how to implement a small application using the EVTK Library to join a few concepts	 *
/* like Database usage, graphical screen use, communication among apps, threading, etc.	 *
/*																					     *
/*****************************************************************************************/
#include "fwkw.h"

class innercontrol : public CControl
{
public:
	innercontrol(IControl* hParent,CTRLLOC* pLocn);
	~innercontrol(void);
	virtual void* Msg(MSGDISPATCH);	
	void* OnDraw(void);	
	void* OnDG2ItemChanged(MSGP);

public:
	ILabelCtl*		LblCompanyName;
	ILabelCtl*		LblCompanyDetails;
	ILabelCtl*      LblDate;
	ILabelCtl*      LblInvoiceNbr;
	ILabelCtl*		LblBillTo;
	ILabelCtl*		LblBillToDetails;
	ILabelCtl*		LblThanksAndNotes;

	IEditCtl*		EdtBillTo;

	IMLTextCtl*     EdtBillToAddress;
	IMLTextCtl*		EdtPaymentTerms;
	IMLTextCtl*		EdtDueDate;	

	IDataGridCtl*	GrdPaymentTerms;
	IDataGridCtl*	GrdItemsToBill;
	IDataGridCtl*	GrdTotals;

	IButtonCtl*     BtnProcess;
};


IControl* MakeMyCtrl(IControl* hParent,CTRLLOC* pLocn)
{
	return (IControl*) new innercontrol(hParent,pLocn);
}

static UINT ctrlid = 100;

innercontrol::innercontrol(IControl* hparent,CTRLLOC* pLocn) : CControl(hparent,ctrlid){
	Locn = *pLocn;
	nBkgndColor = COLOR_APPWORKSPACE; // COLOR_CTRL_BKGND_SOFT;
	CTRLLOC PBLocn = {PARENT_RELATIVE,{20,40,520,50},0}; //Left, Top, Width, Height
	
	CTRLLOC LblLocn1 = {PARENT_RELATIVE,{20,50,110,25},0};
	LblCompanyName = (ILabelCtl*)MakeLabelCtl((IControl*)this,1,&LblLocn1,
		             TEXT("[company website]"),false,false,false);		

	CTRLLOC LblLocn2 = {PARENT_RELATIVE,{20,90,110,25},0};
	LblCompanyDetails = (ILabelCtl*)MakeLabelCtl((IControl*)this,2,&LblLocn2,
		             TEXT("1912 Wayside Lane\n\rSan Francisco, CA 94108\n\r(415) 123 4567\n\rinfo@bloomies.com"),false,false,false);	

	CTRLLOC LblLocn3 = {PARENT_RELATIVE,{825,90,100,25},0};
	LblDate = (ILabelCtl*)MakeLabelCtl((IControl*)this,3,&LblLocn3,
		             TEXT("DATE: April-26, 2013"),false,false,false);	

	CTRLLOC LblLocn4 = {PARENT_RELATIVE,{825,110,110,25},0};
	LblInvoiceNbr = (ILabelCtl*)MakeLabelCtl((IControl*)this,4,&LblLocn4,
	TEXT("INVOICE #: 00005698"),false,false,false);	

	CTRLLOC LblLocn5 = {PARENT_RELATIVE,{20,170,110,25},0};
	LblBillTo = MakeLabelCtl((IControl*)this,5,&LblLocn5,
	TEXT("BILL TO: "),false,false,false);	

	CTRLLOC EdtLocn1 = {PARENT_RELATIVE,{120,170,700,195},0};
	EdtBillTo = (IEditCtl*)MakeEditCtl((IControl*)this,6,&EdtLocn1,NULL);
	EdtBillTo->CtlSetFrameType(FRAMETYPE::RAISED);	
	EdtBillTo->CtlSetNotify(this);

	CTRLLOC LblLocn6 = {PARENT_RELATIVE,{20,200,110,25},0};
	LblBillToDetails = (ILabelCtl*)MakeLabelCtl((IControl*)this,7,&LblLocn6,
	TEXT("ADDRESS: "),false,false,false);	

	WCHAR szBiDiText[] = L"[Use this field for customer's address]";
	IStr*			hMLTestText;
	hMLTestText = MakeStr(szBiDiText);
	CTRLLOC EdtLocn2 = {PARENT_RELATIVE,{120,210,700,300},0};
	EdtBillToAddress = (IMLTextCtl*)MakeRTEdit((IControl*)hparent,8,&EdtLocn2,hMLTestText);	
	EdtBillToAddress->CtlSetNotify(this);

	/* Reminder: Usually the CTRLLOC which stands for Control Location, has the coordinates
	             Left, Top, Width and Height in that order, however, for certain objects like
				 the Grid and the IMLText it seems the coordinates for the Width and Height, 
				 should be calculated as: LEFT + Desired Width and TOP + Desired Height.
	*/ 
	CTRLLOC GridLocn1 = {PARENT_RELATIVE,{20,323,985,346},0};
	GrdPaymentTerms = MakeDataGrid((IControl*)this,9,&GridLocn1);
	GrdPaymentTerms->CtlSetNotify(this);
	GrdPaymentTerms->DGAddColumns(0,2);
	GrdPaymentTerms->DGAddRows(0,1);
	GrdPaymentTerms->DGSetColumnWidth(0,480);
	GrdPaymentTerms->DGSetColumnWidth(1,480);
		
	GrdPaymentTerms->DGSetItemText(0,0,TEXT("PAYMENT TERMS"));
	GrdPaymentTerms->DGSetItemReadOnly(0,0,true);
	GrdPaymentTerms->DGSetItemGreyBkgnd(0,0,true);

	GrdPaymentTerms->DGSetItemText(0,1,TEXT("LEAD TIME AND DUE DATE"));
	GrdPaymentTerms->DGSetItemReadOnly(0,1,true);
	GrdPaymentTerms->DGSetItemGreyBkgnd(0,1,true);		

	WCHAR szPaymentTerms[] = L"[Enter here the Payment Terms]";
	IStr* hMLPaymentTerms = MakeStr(szPaymentTerms);
	CTRLLOC EdtLocn3 = {PARENT_RELATIVE,{20,346,500,415},0};
	EdtPaymentTerms = (IMLTextCtl*)MakeRTEdit((IControl*)hparent,10,&EdtLocn3,hMLPaymentTerms);	
	EdtPaymentTerms->CtlSetNotify(this);

	WCHAR szDueDateTerms[] = L"[Enter here the lead time and due date conditions]";
	IStr* hMLDueDateTerms = MakeStr(szDueDateTerms);
	CTRLLOC EdtLocn4 = {PARENT_RELATIVE,{500,346,985,415},0};
	EdtDueDate = (IMLTextCtl*)MakeRTEdit((IControl*)hparent,11,&EdtLocn4,hMLDueDateTerms);	
	EdtDueDate->CtlSetNotify(this);

									 //  Left, Top,Width,Height
	CTRLLOC GridLocn2 = {PARENT_RELATIVE,{20,450,985,630},0};
	GrdItemsToBill = MakeDataGrid((IControl*)this,12,&GridLocn2);
	GrdItemsToBill->CtlSetNotify(this);
	GrdItemsToBill->DGAddColumns(0,6);
	GrdItemsToBill->DGAddRows(0,8);
	GrdItemsToBill->DGSetColumnWidth(0,40);	
	GrdItemsToBill->DGSetColumnWidth(1,100);
	GrdItemsToBill->DGSetColumnWidth(2,450);
	GrdItemsToBill->DGSetColumnWidth(3,70);
	GrdItemsToBill->DGSetColumnWidth(4,150);
	GrdItemsToBill->DGSetColumnWidth(5,150);
	
	GrdItemsToBill->DGSetItemText(0,0,TEXT("ID"));
	GrdItemsToBill->DGSetItemReadOnly(0,0,true);
	GrdItemsToBill->DGSetItemGreyBkgnd(0,0,true);

	GrdItemsToBill->DGSetItemText(0,1,TEXT("CODE"));
	GrdItemsToBill->DGSetItemReadOnly(0,1,true);
	GrdItemsToBill->DGSetItemGreyBkgnd(0,1,true);

	GrdItemsToBill->DGSetItemText(0,2,TEXT("DESCRIPTION"));
	GrdItemsToBill->DGSetItemReadOnly(0,2,true);
	GrdItemsToBill->DGSetItemGreyBkgnd(0,2,true);

	GrdItemsToBill->DGSetItemText(0,3,TEXT("QTY"));
	GrdItemsToBill->DGSetItemReadOnly(0,3,true);
	GrdItemsToBill->DGSetItemGreyBkgnd(0,3,true);

	GrdItemsToBill->DGSetItemText(0,4,TEXT("PRICE"));
	GrdItemsToBill->DGSetItemReadOnly(0,4,true);
	GrdItemsToBill->DGSetItemGreyBkgnd(0,4,true);

	GrdItemsToBill->DGSetItemText(0,5,TEXT("AMOUNT"));
	GrdItemsToBill->DGSetItemReadOnly(0,5,true);
	GrdItemsToBill->DGSetItemGreyBkgnd(0,5,true);
	GrdItemsToBill->CtlSetSelColors(COLOR_WHITE,COLOR_BLACK);

	CTRLLOC GridLocn3 = {PARENT_RELATIVE,{735,640,985,750},0};
	GrdTotals = MakeDataGrid((IControl*)this,13,&GridLocn3);
	GrdTotals->CtlSetNotify(this);
	GrdTotals->DGAddColumns(0,2);
	GrdTotals->DGAddRows(0,3);	
	GrdTotals->DGSetColumnWidth(0,100);
	GrdTotals->DGSetColumnWidth(1,150);
	
	GrdTotals->DGSetItemText(0,0,TEXT("SUBTOTAL"));
	GrdTotals->DGSetItemReadOnly(0,0,true);
	GrdTotals->DGSetItemRdOnlyBkgnd(0,0,true);

	GrdTotals->DGSetItemText(1,0,TEXT("TAX"));
	GrdTotals->DGSetItemReadOnly(1,0,true);
	GrdTotals->DGSetItemRdOnlyBkgnd(1,0,true);

	GrdTotals->DGSetItemText(2,0,TEXT("TOTAL"));
	GrdTotals->DGSetItemReadOnly(2,0,true);
	GrdTotals->DGSetItemRdOnlyBkgnd(2,0,true);
	GrdTotals->CtlSetSelColors(COLOR_WHITE,COLOR_BLACK);		
	
	CTRLLOC LblLocn7 = {PARENT_RELATIVE,{50,640,110,25},0};
	LblThanksAndNotes = (ILabelCtl*)MakeLabelCtl((IControl*)this,14,&LblLocn7,
						TEXT("Make all checks payable to the Company's Name above\n\rIf you have any questions please call or email us\n\rThank you for your business"),
						false,false,false);
	
	CTRLLOC ButtonLocn = {PARENT_RELATIVE,{550,655,700,685},0};
	BtnProcess = MakeButtonCtl((IControl*)this,2,&ButtonLocn, BTN3D,0,
	TEXT("    PROCESS INVOICE    "),NULL,false,false);
	BtnProcess->CtlSetBkColor(COLOR_BLUE);
	BtnProcess->CtlSetTxColor(COLOR_WHITE);

	BtnProcess->CtlSetNotify(this);
}

innercontrol::~innercontrol(void){}


void* innercontrol::OnDG2ItemChanged(MSGP)
{
	MPARMPTR(MSGS_DGItemChanged*,pmsg);
	IMObject* hDGrid2 = pmsg->hDGrid2;
	UINT nSelRow = pmsg->nSelRow;
	UINT nSelCol = pmsg->nSelCol;

	UINT oid1 = (int)GrdItemsToBill->DbId();
	UINT oid2 = (int)GrdTotals->DbId();
	return IM_RTN_NOTHING;
}

void* innercontrol::Msg(MSGDISPATCH)
{
	switch(MSGID)
	{
		case MSG_DbOType:return MRTNVAL(FWK_CTRLCLASS+CTRL_CONTAINER);
		case MSG_CtlDraw: return OnDraw();
		case MSG_WinClose:		
			return IM_RTN_NOTHING;
	}	
	return MSGFWDBASE(CControl,MSGID);
}

void* innercontrol::OnDraw(void)
{
	if(!fVisible || !fSized)
		return IM_RTN_NOTHING;
	
	hDraw->IDrawFColor(nBkgndColor);
	hDraw->IDrawFRectP(&CRect);

	IControl* hCtrl = (IControl*)DbFirstSL();
	while(hCtrl && (hCtrl != (IControl*)hSLEnd))
	{
		hCtrl->CtlDraw();
		hCtrl = (IControl*)hCtrl->DbNextMain();
	}
	
	hDraw->IDrawTColor(COLOR_BLUE);
	hDraw->IDrawSetFont(TEXT("Arial.ttf"),36,0,true,true);
	hDraw->IDrawText(25,43,TEXT("COMPANY NAME"));

	hDraw->IDrawTColor(COLOR_RED);
	hDraw->IDrawSetFont(TEXT("Arial.ttf"),50,0,true,true);
	hDraw->IDrawText(800,50,TEXT("INVOICE"));
		
	hDraw->IDrawLColor(COLOR_3DDKSHADOW);
	hDraw->IDrawDLine(20,80,980,80);	

	hDraw->IDrawImgRefresh(&CRect);
	return IM_RTN_NOTHING;
}