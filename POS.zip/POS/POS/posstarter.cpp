#include "fwkw.h"
#include "winmain.h"

IControl* MakeMyCtrl(IControl* hParent,CTRLLOC* pLocn);

class posstarter : public IMObject
{
public:
	posstarter(void);
	~posstarter(void);
	virtual void* Msg(MSGDISPATCH);	
	
public:
	IWindow*        hWindow;	
	IControl*		hInnerControl;						
};

IApplication* MakeApplication(void)
{
	return (IApplication*) new posstarter();
}

posstarter::posstarter(void){
	pApplication = this;	
	hWindow = NULL;

	LoadDefaultResources();

	SESSION* ssnptr = hSession->SsnGetDataPtr();
	ssnptr->fUntitledWin = false;

	hWindow = MakeWindow(WINTYPE_DOCWIN,NULL,0,0,1024,768,true,false);
	hWindow->WinQuitOnClose();	
	hWindow->WinSetTitle(TEXT("Point of Sale (INVOICING)"));	

	CTRLLOC CtlLocn = {ALL,{0,0,0,0},0};
	hInnerControl = MakeMyCtrl(hWindow,&CtlLocn);	
	
	hWindow->WinCtrlsChanged();
	hWinMgr->WMgrSetFocus(hInnerControl);			
}




posstarter::~posstarter(void){
}

static WCHAR szAppVersion[] = VER_DISPLAY_CT;
static char szAppDate[] = __DATE__;
static WCHAR* szAppName = TEXT("posstarter\0");

void* posstarter::Msg(MSGDISPATCH)
{
	switch(MSGID){
	    case MSG_AppVersionText:	return MRTNVAL(szAppVersion);
		case MSG_AppVersionDate:	return MRTNVAL(szAppDate);
		case MSG_AppName:			return MRTNVAL(szAppName);
		case MSG_CtlWindow:			return MRTNVAL(hWindow);
		case MSG_WinClose :			((IWindow*)hInnerControl)->WinClose();
			return IM_RTN_NOTHING;
	}	
	return IM_RTN_NOTHING;
}